A Policy-Bounded Agentic Framework for Autonomous Governance of Cloud Data Pipelines
IEEE journal manuscript - LaTeX source

Build (Overleaf): upload this zip as a new project; main document = main.tex;
compiler = pdfLaTeX; run LaTeX -> BibTeX -> LaTeX -> LaTeX (Overleaf does this automatically).

Build (local): pdflatex main && bibtex main && pdflatex main && pdflatex main
   or:          tectonic main.tex

Contents
  main.tex                 IEEEtran [journal] master file
  refs.bib                 30 references (IEEE style via IEEEtran.bst)
  sections/                abstract and Sections I-IX, plus back matter
  generated/               tables and plots generated from the campaign data, and
                           numbers.tex (every reported number as a \N... macro)
  figures/                 Fig. 1, seven-layer system architecture (vector PDF)

Do not edit files in generated/ by hand: they are regenerated from the per-run data in the
project repository (make paper-repro-quick).
